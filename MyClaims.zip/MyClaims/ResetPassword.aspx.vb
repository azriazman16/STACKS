﻿
Imports System.Data.SqlClient

Partial Class ResetPassword
    Inherits System.Web.UI.Page

    Private Sub ResetPassword_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender
        If Request.QueryString("key") = "" Then
            Dim customMesej As String = "Permintaan Tidak Sah"
            Dim message As String = "alert('" & customMesej & "')"
            ScriptManager.RegisterClientScriptBlock(TryCast(sender, Control), Me.GetType(), "alert", message, True)

            'Response.Redirect("Login.aspx")
        Else

        End If

        Using myConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("webcon_ConnectionStr").ConnectionString)
            myConnection.Open()

            Const getHash As String = "select * from ForgotPassword where Forgot_HashKey=@Forgot_HashKey"
            Dim cmd As New SqlCommand(getHash, myConnection)
            cmd.Parameters.AddWithValue("@Forgot_HashKey", Request.QueryString("key"))

            Dim reader As SqlDataReader = cmd.ExecuteReader

            If reader.Read Then

                emailId.Text = reader.Item("Forgot_Email")


            Else

                Dim customMesej As String = "Permintaan Tidak Sah"
                Dim message As String = "alert('" & customMesej & "')"
                ScriptManager.RegisterClientScriptBlock(TryCast(sender, Control), Me.GetType(), "alert", message, True)
                btnForgot.Enabled = False
            End If
            myConnection.Close()
        End Using
    End Sub

    Private Sub btnForgot_Click(sender As Object, e As EventArgs) Handles btnForgot.Click
        Using myConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("webcon_ConnectionStr").ConnectionString)
            myConnection.Open()

            Const getHash As String = "update Login_User set Password=@Password,updated_at=@updated_at where Staff_Email=@Staff_Email"
            Dim cmd As New SqlCommand(getHash, myConnection)
            cmd.Parameters.AddWithValue("@Password", GlobalClass.Encrypt(passwordNew.Text, "stacks", True))
            cmd.Parameters.AddWithValue("@Staff_Email", emailId.Text)
            cmd.Parameters.AddWithValue("@updated_at", DateTime.Now)

            cmd.ExecuteNonQuery()


            Const delete As String = "delete from ForgotPassword where Forgot_Email=@Forgot_Email"
            Dim cmd2 As New SqlCommand(delete, myConnection)
            cmd2.Parameters.AddWithValue("@Forgot_Email", emailId.Text)

            cmd2.ExecuteNonQuery()


            Dim customMesej As String = "Kata Laluan Berjaya Ditukar"
            Dim message As String = "alert('" & customMesej & "')"
            ScriptManager.RegisterClientScriptBlock(TryCast(sender, Control), Me.GetType(), "alert", message, True)


            myConnection.Close()

            Response.AppendHeader("Refresh", "1;url=Login.aspx")
        End Using
    End Sub
End Class
