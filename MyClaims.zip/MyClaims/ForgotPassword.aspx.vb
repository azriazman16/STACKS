﻿
Imports System.Data.SqlClient

Partial Class ForgotPassword
    Inherits System.Web.UI.Page

    Private Sub btnForgot_Click(sender As Object, e As EventArgs) Handles btnForgot.Click
        Using myConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("webcon_ConnectionStr").ConnectionString)
            myConnection.Open()
            Dim resetcode As String = Guid.NewGuid().ToString()

            Const getDetail As String = "select * from Login_User where Staff_Email=@Staff_Email"
            Dim cmd As New SqlCommand(getDetail, myConnection)
            cmd.Parameters.AddWithValue("@Staff_Email", emailId.Text)
            Dim reader As SqlDataReader = cmd.ExecuteReader

            If reader.Read Then
                'Dim hash As String = GlobalClass.GenerateSHA256String(reader.Item("Staff_Id"))
                Const setHash As String = "Insert Into ForgotPassword (Forgot_Email,Forgot_HashKey) values (@Forgot_Email,@Forgot_HashKey)"
                Dim cmd2 As New SqlCommand(setHash, myConnection)
                cmd2.Parameters.AddWithValue("@Forgot_Email", emailId.Text)
                cmd2.Parameters.AddWithValue("@Forgot_HashKey", resetcode)

                cmd2.ExecuteNonQuery()

                'amend this later

                'Using mm As New MailMessage("""Tanjong Puteri Golf Resort""webadmin@tpgr.com", txtEmail.Text)

                '    Dim FinalBody As String = ""
                '    FinalBody = FinalBody & "<font face='Arial'>"
                '    FinalBody = FinalBody & "Dear " + reader.Item("Golf_User_Name") + ",<br><br>"
                '    FinalBody = FinalBody & "We have received a request to reset your password.<br/><br/>Click <a href = '" + Request.Url.AbsoluteUri.Replace("reset.aspx", Convert.ToString("forgotlanding.aspx?key=") & resetcode) + "'>Here </a> to reset your password."
                '    FinalBody = FinalBody & "<br/></br><br/><br/>Thank You.</br><br/><i style='font-size:small'>---This Is Computer Generated Email. Please Don't Reply This Email---</i>"

                '    FinalBody = FinalBody & "</font>"

                '    mm.Subject = "Reset Password - Online Golf Booking @Tanjong Puteri Golf Resort"
                '    mm.Body = FinalBody

                '    mm.IsBodyHtml = True
                '    Dim smtp As New SmtpClient()
                '    smtp.Host = "mail.tpgr.com"
                '    smtp.EnableSsl = False
                '    Dim NetworkCred As New NetworkCredential("webadmin@tpgr.com", "U626%Q%YXY);")
                '    smtp.UseDefaultCredentials = True
                '    smtp.Credentials = NetworkCred
                '    smtp.Port = 587
                '    smtp.Send(mm)
                'End Using

                Dim customMesej As String = "Sila Semak Emel anda untuk tindakan seterusnya."
                Dim message As String = "alert('" & customMesej & "')"
                ScriptManager.RegisterClientScriptBlock(TryCast(sender, Control), Me.GetType(), "alert", message, True)
            Else

                Dim customMesej As String = "Emel tidak wujud!"
                Dim message As String = "alert('" & customMesej & "')"
                ScriptManager.RegisterClientScriptBlock(TryCast(sender, Control), Me.GetType(), "alert", message, True)

            End If
            reader.Close()

            myConnection.Close()

            emailId.Text = ""

        End Using
    End Sub
End Class
