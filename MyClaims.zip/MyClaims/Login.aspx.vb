﻿
Imports System.Data.SqlClient

Partial Class Login
    Inherits System.Web.UI.Page

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Using myConnection As New Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings("webcon_ConnectionStr").ConnectionString)


            Dim txtStaffId = Me.staffId.Text
            Dim paraPassword = Me.password.Text
            Dim txtPassword As String = GlobalClass.Encrypt(paraPassword, "stacks", True)

            Const SQL As String = "SELECT *  FROM Login_User where Staff_Id=@Staff_Id and Password=@Password"
            Dim myCommand As New SqlCommand(SQL, myConnection)
            myCommand.Parameters.AddWithValue("@Staff_Id", txtStaffId)
            myCommand.Parameters.AddWithValue("@Password", txtPassword)

            myConnection.Open()

            Dim myReader As SqlDataReader = myCommand.ExecuteReader

            If myReader.Read Then
                Dim isActive = myReader.Item("Is_Active").ToString

                If isActive = True Then

                    Dim staffId As String = myReader.Item("Staff_Id").ToString
                    Dim staffEmail As String = myReader.Item("Staff_Email").ToString

                    Session.Item("sessionStaffId") = staffId
                    Session.Item("sessionStaffEmail") = staffEmail

                    Response.Redirect("Default.aspx")
                Else
                    lblMessage.Text = "Sila Semak Emel anda untuk pengesahan terlebih dahulu!"
                End If

            Else

                lblMessage.Text = "Maklumat yang dimasukkan tidak sah!"

            End If

            myConnection.Close()
        End Using
    End Sub
End Class
