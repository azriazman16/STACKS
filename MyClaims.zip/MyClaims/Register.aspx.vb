﻿
Imports System.Data.SqlClient

Partial Class Register
    Inherits System.Web.UI.Page

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Using myConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("webcon_ConnectionStr").ConnectionString)


            Dim txtStaffId = Me.staffId.Text
            Dim txtEmail = Me.emailId.Text
            Dim paraPassword = Me.password.Text
            Dim txtPassword As String = GlobalClass.Encrypt(paraPassword, "stacks", True)

            Const SQL As String = "SELECT *  FROM Login_User where Staff_Id=@Staff_Id"
            Dim myCommand As New SqlCommand(SQL, myConnection)
            myCommand.Parameters.AddWithValue("@Staff_Id", txtStaffId)

            myConnection.Open()

            Dim myReader As SqlDataReader = myCommand.ExecuteReader

            If myReader.Read Then
                lblMessage.Text = "Maklumat Pengguna telah wujud. Sila Log Masuk"
            Else
                Const checkHRMS As String = "SELECT *  FROM HRMS_User where EMPLID=@EMPLID and EMPL_STATUS=@EMPL_STATUS"
                Dim myCommandHRMS As New SqlCommand(checkHRMS, myConnection)
                myCommandHRMS.Parameters.AddWithValue("@EMPLID", txtStaffId)
                myCommandHRMS.Parameters.AddWithValue("@EMPL_STATUS", "A")

                Dim myReaderHRMS As SqlDataReader = myCommandHRMS.ExecuteReader
                If myReaderHRMS.Read Then
                    Const sqlRegister As String = "INSERT INTO Login_User (Staff_Id,Staff_Email,Password,Is_Active,created_at) VALUES (@Staff_Id,@Staff_Email,@Password,0,@created_at)"
                    Dim sqlcommand As New SqlCommand(sqlRegister, myConnection)
                    sqlcommand.Parameters.AddWithValue("@Staff_Id", txtStaffId.Trim.ToString)
                    sqlcommand.Parameters.AddWithValue("@Staff_Email", txtEmail.Trim.ToString)
                    sqlcommand.Parameters.AddWithValue("@Password", txtPassword)
                    sqlcommand.Parameters.AddWithValue("@created_at", DateTime.Now)
                    sqlcommand.ExecuteNonQuery()

                    lblMessage.Text = "Pendaftaran Berjaya. Sila Semak Emel untuk pengesahan"
                    staffId.Text = ""
                    emailId.Text = ""
                    password.Text = ""

                Else
                    lblMessage.Text = "Maklumat anda tidak ditemui"
                End If




                'will add send email here
            End If

            myConnection.Close()
        End Using
    End Sub
End Class
