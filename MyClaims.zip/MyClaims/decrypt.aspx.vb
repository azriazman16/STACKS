﻿
Partial Class decrypt
    Inherits System.Web.UI.Page

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        TextBox2.Text = GlobalClass.Decrypt(TextBox1.Text, "kmbportal", True)
    End Sub
End Class
