﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Private Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        'MsgBox(DropDownList1.SelectedItem.ToString)

        If DropDownList1.SelectedItem.ToString = "Tuntutan Perjalanan" Then

            Dim trxID As String = DateTime.Now.ToString() & Session.Item("sessionStaffId")
            trxID = "AP" + trxID.GetHashCode().ToString("x").ToUpper
            lblNoClaims.Text = trxID
        ElseIf DropDownList1.SelectedItem.ToString = "Tuntutan Pelbagai" Then

            Dim trxID As String = DateTime.Now.ToString() & Session.Item("sessionStaffId")
            trxID = "G" + trxID.GetHashCode().ToString("x").ToUpper
            lblNoClaims.Text = trxID

        Else
            lblNoClaims.Text = "N/A"
        End If
    End Sub
End Class
