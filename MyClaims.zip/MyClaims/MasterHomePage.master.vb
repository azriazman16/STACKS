﻿
Imports System.Data.SqlClient

Partial Class MasterHomePage
    Inherits System.Web.UI.MasterPage

    Public wMetaTag, wSiteTitle, writeDescriptionTag As String

    Private Sub MasterHomePage_Load(sender As Object, e As EventArgs) Handles Me.Load
        '//start write menu

    End Sub

    Private Sub MasterHomePage_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender
        If Session.Item("sessionStaffId") Is Nothing Then
            Response.Redirect("login.aspx")

        Else

            Using myConnection As New Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings("webcon_ConnectionStr").ConnectionString)


                Const SQL As String = "SELECT *  FROM HRMS_User where EMPLID=@EMPLID"
                Dim myCommand As New SqlCommand(SQL, myConnection)

                myCommand.Parameters.AddWithValue("@EMPLID", Session.Item("sessionStaffId").ToString)

                myConnection.Open()

                Dim myReader As SqlDataReader = myCommand.ExecuteReader

                If myReader.Read Then

                    lblName.Text = myReader.Item("NAME")
                    lblName2.Text = myReader.Item("NAME")
                    lblName3.Text = myReader.Item("NAME")
                    lblBand.Text = myReader.Item("GRADE")
                    lblEmail.Text = Session.Item("sessionStaffEmail")
                    lblStaffId.Text = myReader.Item("EMPLID")






                End If

                myConnection.Close()
            End Using
        End If
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Session.Abandon()

        Response.Redirect("Login.aspx")
    End Sub
End Class

