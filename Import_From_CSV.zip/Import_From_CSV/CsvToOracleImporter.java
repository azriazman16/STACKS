import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class CsvToOracleImporter {

    private static Logger logger = Logger.getLogger(CsvToOracleImporter.class.getName());

    public static void main(String[] args) throws CsvValidationException {
        // Set up logging
        try {
            Properties properties = loadProperties("config.properties");
            String logFilePath = properties.getProperty("logFilePath");

            FileHandler fileHandler = new FileHandler(logFilePath);
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Load properties from external file
        Properties properties = null;
        try {
            properties = loadProperties("config.properties");
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        // Database connection details
        String jdbcUrl = properties.getProperty("jdbcUrl");
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");

        // CSV file path
        String csvFilePath = properties.getProperty("csvFilePath");

        // Destination folder for the CSV file after completion
        String backupFolder = properties.getProperty("backupFolder");

        // Table name
        String tableName = properties.getProperty("tableName");

        try {
            // Load the Oracle JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Establish the database connection
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Read CSV file to get the header
            List<String> header;
            try (CSVReader readerHeader = new CSVReader(new FileReader(csvFilePath))) {
                String[] headerArray;
                try {
                    headerArray = readerHeader.readNext();
                    header = (headerArray != null) ? Arrays.asList(headerArray) : null;
                } catch (com.opencsv.exceptions.CsvValidationException e) {
                    e.printStackTrace();
                    // Handle the exception as needed (e.g., log, exit program, etc.)
                    return;
                }
            }

            // Prepare the SQL statement for inserting data with dynamic placeholders
            String insertSql = createInsertStatement(tableName, header);
            PreparedStatement preparedStatement = connection.prepareStatement(insertSql);

            // Read CSV file using OpenCSV
            try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))) {
                // Skip the header line
                reader.readNext();

                String[] nextLine;
                while ((nextLine = reader.readNext()) != null) {
                    try {
                        // Set parameters dynamically based on the header
                        for (int i = 0; i < header.size(); i++) {
                            String value = nextLine[i];
                            if (value.isEmpty()) {
                                preparedStatement.setNull(i + 1, java.sql.Types.NULL);
                            } else {
                                preparedStatement.setString(i + 1, value);
                            }
                        }

                        // Execute the insert statement
                        preparedStatement.executeUpdate();

                        // Log success
                        logger.log(Level.INFO, "Data inserted successfully: " + String.join(", ", nextLine));
                    } catch (SQLException e) {
                        // Log error
                        logger.log(Level.SEVERE, "Error inserting data: " + String.join(", ", nextLine), e);
                    }
                }
            }

            // Move the CSV file to the backup folder
            moveCsvFile(csvFilePath, backupFolder);

            // Close resources
            preparedStatement.close();
            connection.close();

            System.out.println("Data import completed!");

        } catch (ClassNotFoundException | SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    private static Properties loadProperties(String fileName) throws IOException {
        Properties properties = new Properties();
        try (FileInputStream input = new FileInputStream(fileName)) {
            properties.load(input);
        }
        return properties;
    }

    private static void moveCsvFile(String sourcePath, String backupFolder) throws IOException {
        Path source = Paths.get(sourcePath);
        Path destination = Paths.get(backupFolder, source.getFileName().toString());

        Files.move(source, destination);

        System.out.println("CSV file moved to: " + destination.toString());
    }

    private static String createInsertStatement(String tableName, List<String> columns) {
        StringBuilder sql = new StringBuilder("INSERT INTO ");
        sql.append(tableName).append(" (");

        // Append column names
        for (String column : columns) {
            sql.append(column).append(", ");
        }
        sql.setLength(sql.length() - 2);  // Remove the last comma and space
        sql.append(") VALUES (");

        // Append placeholders for values
        for (int i = 0; i < columns.size(); i++) {
            sql.append("?, ");
        }
        sql.setLength(sql.length() - 2);  // Remove the last comma and space
        sql.append(")");

        return sql.toString();
    }
}
